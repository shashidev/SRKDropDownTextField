//
//  ViewController.h
//  SRKDropDownTextField
//
//  Created by Kumar on 22/05/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SRKDropDownTextField.h"

@interface ViewController : UIViewController
{
    IBOutlet SRKDropDownTextField *textFieldTextPicker;
    IBOutlet SRKDropDownTextField *textFieldTimePicker;
    
     IBOutlet SRKDropDownTextField *textFieldDatePicker;
    
    IBOutlet SRKDropDownTextField *textFieldDateTimePicker;
}


@end

