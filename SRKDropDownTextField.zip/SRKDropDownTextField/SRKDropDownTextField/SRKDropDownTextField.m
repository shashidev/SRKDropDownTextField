//
//  SRKDropDownTextField.m
//  SRKDropDownTextField
//  Created by Shashi Ranjan Kumar on 22/05/16.
//  Copyright © 2016 Shashi Ranjan Kumar. All rights reserved.

// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.


#import "SRKDropDownTextField.h"

@interface SRKDropDownTextField()<UIPickerViewDelegate,UIPickerViewDataSource>
{
    NSArray *internalItems;
}
@property(nonatomic,retain)UIPickerView *pickerView;
@property(nonatomic,retain)UIDatePicker *timePicker;
@property(nonatomic,retain)UIDatePicker *datePicker;
@property(nonatomic,retain)UIDatePicker* dateTimePicker;
@property (nullable, nonatomic, retain) NSDateFormatter *dropDownDateTimeFormater;
@property (nullable, nonatomic, retain) NSDateFormatter *dropDownTimeFormater;
@property (nullable, nonatomic, retain) NSDateFormatter *dropDownDateFormater;

@end

@implementation SRKDropDownTextField



-(void)initilization
{
    
        self.dropDownDateFormater = [[NSDateFormatter alloc] init];
        [self.dropDownDateFormater setDateStyle:NSDateFormatterMediumStyle];
        [self.dropDownDateFormater setTimeStyle:NSDateFormatterNoStyle];
   
    
        self.dropDownTimeFormater = [[NSDateFormatter alloc] init];
        [self.dropDownTimeFormater setDateStyle:NSDateFormatterNoStyle];
        [self.dropDownTimeFormater setTimeStyle:NSDateFormatterShortStyle];
    
        self.dropDownDateTimeFormater = [[NSDateFormatter alloc] init];
        [self.dropDownDateTimeFormater setDateStyle:NSDateFormatterMediumStyle];
        [self.dropDownDateTimeFormater setTimeStyle:NSDateFormatterShortStyle];
        [self setDropDownMode:SRKDropDownModeTextPicker];
}

-(void)awakeFromNib
{
    [super awakeFromNib];
    [self initilization];
}

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return internalItems.count;
}
-(UIView*)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view
{
    UILabel *labelText = (UILabel*)view;
    
    if (labelText == nil)
    {
        labelText = [[UILabel alloc] init];
        [labelText setTextAlignment:NSTextAlignmentCenter];
        [labelText setAdjustsFontSizeToFitWidth:YES];
        labelText.backgroundColor = [UIColor clearColor];
        labelText.backgroundColor = [UIColor clearColor];
    }
    
    
    
    
    NSString *text = [internalItems objectAtIndex:row];
    
    [labelText setText:text];
    
    return labelText;


}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    NSString *str=[internalItems objectAtIndex:row];
    
    BOOL canSelected =YES;
    
    if(canSelected)
    {
        super.text=str;
        [self.delegate respondsToSelector:@selector(textField:didSelectItem:)];
        [self.delegate textField:self didSelectItem:str];
    }
    else
    {
        super.text=@"";
    }
}

-(void)setDropDownMode :(SRKDropDownMode )dropDownMode
{
    _dropDownMode=dropDownMode;
    switch (_dropDownMode) {
        case SRKDropDownModeTextPicker:
            self.inputView=self.pickerView;
            break;
        case SRKDropDownModeTimePicker:
            self.inputView=self.timePicker;
            break;
        case SRKDropDownModeDatePicker:
            self.inputView=self.datePicker;
            break;
        case SRKDropDownModeDateTimePicker:
            self.inputView=self.dateTimePicker;
            break;
            
        default:
            break;
    }
}
-(UIPickerView *)pickerView
{
    if(!_pickerView)
    {
        _pickerView = [[UIPickerView alloc] init];
        [_pickerView setAutoresizingMask:(UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight)];
        [_pickerView setShowsSelectionIndicator:YES];
        [_pickerView setDelegate:self];
        [_pickerView setDataSource:self];
    }
    return _pickerView;
}

- (UIDatePicker *) timePicker
{
    if (!_timePicker)
    {
        _timePicker = [[UIDatePicker alloc] init];
        [_timePicker setAutoresizingMask:(UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight)];
        [_timePicker setDatePickerMode:UIDatePickerModeTime];
        [_timePicker addTarget:self action:@selector(timeChanged:) forControlEvents:UIControlEventValueChanged];
    }
    return _timePicker;
}

- (UIDatePicker *) datePicker
{
    if (!_datePicker)
    {
        _datePicker = [[UIDatePicker alloc] init];
        [_datePicker setAutoresizingMask:(UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight)];
        [_datePicker setDatePickerMode:UIDatePickerModeDate];
        [_datePicker addTarget:self action:@selector(dateChanged:) forControlEvents:UIControlEventValueChanged];
    }
    return _datePicker;
}
- (UIDatePicker *) dateTimePicker
{
    if (!_dateTimePicker)
    {
        _dateTimePicker = [[UIDatePicker alloc] init];
        [_dateTimePicker setAutoresizingMask:(UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight)];
        [_dateTimePicker setDatePickerMode:UIDatePickerModeDateAndTime];
        [_dateTimePicker addTarget:self action:@selector(dateTimeChanged:) forControlEvents:UIControlEventValueChanged];
    }
    return _dateTimePicker;
}


- (void)setItemList:(NSArray *)itemList
{
    internalItems = itemList;

}
- (void)timeChanged:(UIDatePicker *)tPicker
{
    [self setSelectedItem:[self.dropDownTimeFormater stringFromDate:tPicker.date] animated:NO shouldNotifyDelegate:YES];
}
- (void)dateChanged:(UIDatePicker *)dPicker
{
    [self setSelectedItem:[self.dropDownDateFormater stringFromDate:dPicker.date] animated:NO shouldNotifyDelegate:YES];
}
- (void)dateTimeChanged:(UIDatePicker *)dtPicker
{
    
    [self setSelectedItem:[self.dropDownDateTimeFormater stringFromDate:dtPicker.date] animated:NO shouldNotifyDelegate:YES];
}

-(void)setSelectedItem:(NSString *)selectedItem animated:(BOOL)animated shouldNotifyDelegate:(BOOL)shouldNotifyDelegate
{
    switch (_dropDownMode)
    {
        case SRKDropDownModeTextPicker:
            if ([internalItems containsObject:selectedItem])
            {
               
                if(shouldNotifyDelegate && [self.delegate respondsToSelector:@selector(textField:didSelectItem:)])
                    [self.delegate textField:self didSelectItem:selectedItem];
            }
            break;
        case SRKDropDownModeDatePicker:
        {
            NSDate *date = [self.dropDownDateFormater dateFromString:selectedItem];
            if (date)
            {
                super.text = selectedItem;
              [self.datePicker setDate:date animated:animated];
                
                //Setting delegate for date
                if(shouldNotifyDelegate && [self.delegate respondsToSelector:@selector(textField:didSelectDate:)])
                {
                    [self.delegate textField:self didSelectDate:selectedItem];
                }
                
            }
            else if ([selectedItem length])
            {
                NSLog(@"Invalid date or date format:%@",selectedItem);
            }
            break;
        }
        case SRKDropDownModeTimePicker:
        {
            NSDate *date = [self.dropDownTimeFormater dateFromString:selectedItem];
            if (date)
            {
                super.text = selectedItem;
                [self.timePicker setDate:date animated:animated];
                
                //Setting delegate for date
                if(shouldNotifyDelegate && [self.delegate respondsToSelector:@selector(textField:didSelectDate:)])
                {
                    [self.delegate textField:self didSelectDate:selectedItem];
                }
                
              
            }
            else if([selectedItem length])
            {
                NSLog(@"Invalid time or time format:%@",selectedItem);
            }
            break;
        }
        case SRKDropDownModeDateTimePicker:
        {
            NSDate *date = [self.dropDownDateTimeFormater dateFromString:selectedItem];
            if (date)
            {
                super.text = selectedItem;
               [self.dateTimePicker setDate:date animated:animated];
                
                //Setting delegate for date
                if(shouldNotifyDelegate && [self.delegate respondsToSelector:@selector(textField:didSelectDate:)])
                {
                    [self.delegate textField:self didSelectDate:selectedItem];
                }
                
            }
            else if([selectedItem length])
            {
                NSLog(@"Invalid time or time format:%@",selectedItem);
            }
            break;
        }
        case SRKDropDownModeTextField:{
            super.text = selectedItem;
            if(shouldNotifyDelegate && [self.delegate respondsToSelector:@selector(textField:didSelectItem:)])
                [self.delegate textField:self didSelectItem:selectedItem];
        }
            break;
    }
}
@end
