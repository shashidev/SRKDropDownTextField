//
//  ViewController.m
//  SRKDropDownTextField
//
//  Created by Kumar on 22/05/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<SRKDropDownTextFieldDelegate>
{
    NSMutableArray *items;
}
@property(nonatomic,retain)UIPickerView *pickerView;
- (IBAction)clickMe:(id)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIToolbar *toolbar = [[UIToolbar alloc] init];
    [toolbar setBarStyle:UIBarStyleBlackTranslucent];
    toolbar.tintColor=[UIColor greenColor];
    toolbar.barTintColor=[UIColor redColor];
    [toolbar sizeToFit];
    UIBarButtonItem *buttonflexible = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIBarButtonItem *buttonDone = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(doneClicked:)];
    
    [toolbar setItems:[NSArray arrayWithObjects:buttonflexible,buttonDone, nil]];
  
    textFieldTextPicker.inputAccessoryView = toolbar;
    textFieldTimePicker.inputAccessoryView = toolbar;
    textFieldDatePicker.inputAccessoryView = toolbar;
    textFieldDateTimePicker.inputAccessoryView=toolbar;
   
    
   
    NSArray *item=[NSArray arrayWithObjects:@"London",@"Johannesburg",@"Moscow",@"Mumbai",@"Tokyo",@"Sydney", nil];
    [textFieldTextPicker setItemList:item];
   // [textFieldTimePicker setItemList:item];
  //  textFieldTextPicker.delegate=self;
 
    [textFieldTimePicker setDropDownMode:SRKDropDownModeTimePicker];
    [textFieldDatePicker setDropDownMode:SRKDropDownModeDatePicker];
    [textFieldDateTimePicker setDropDownMode:SRKDropDownModeDateTimePicker];
  
    
    
}
-(void)doneClicked:(UIBarButtonItem*)button
{
    [self.view endEditing:YES];
}
-(void)textField:(nullable  SRKDropDownTextField *)textFie didSelectItem:(nullable NSString *)text
{
   NSLog(@"%@: %@",NSStringFromSelector(_cmd),text);
}
-(void)textField:(SRKDropDownTextField *)textField didSelectDate:(NSString *)date
{
    NSLog(@"%@: %@",NSStringFromSelector(_cmd),date);
}

@end
